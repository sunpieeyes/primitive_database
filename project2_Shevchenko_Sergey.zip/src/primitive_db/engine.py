import shlex
import prompt
from .utils import load_metadata, save_metadata, load_table_data, save_table_data
from .core import (
    create_table,
    drop_table,
    list_tables,
    insert,
    select,
    update,
    delete,
    info,
    print_help,
)
from .decorators import handle_db_errors, log_time, create_cacher

METADATA_FILE = "db_meta.json"
DATA_DIR = "data/"

# Кэш для select
cache = create_cacher()


def parse_where_clause(where_parts):
    """Парсит строку вида 'column = value' в словарь."""
    key, val = " ".join(where_parts).split("=")
    key = key.strip()
    val = val.strip().strip('"').strip("'")
    if val.lower() == "true":
        val = True
    elif val.lower() == "false":
        val = False
    elif val.isdigit():
        val = int(val)
    return {key: val}


def parse_set_clause(set_parts):
    """Парсит строку вида 'column = value' в словарь для update."""
    key, val = " ".join(set_parts).split("=")
    key = key.strip()
    val = val.strip().strip('"').strip("'")
    if val.lower() == "true":
        val = True
    elif val.lower() == "false":
        val = False
    elif val.isdigit():
        val = int(val)
    return {key: val}


@handle_db_errors
def run():
    """Главный цикл программы."""
    print("*** Добро пожаловать в базу данных ***")
    metadata = load_metadata(METADATA_FILE)

    while True:
        user_input = prompt.string(">>> Введите команду: ")
        if not user_input:
            continue

        args = shlex.split(user_input)
        command = args[0].lower()

        if command == "exit":
            print("До свидания!")
            break

        elif command == "help":
            print_help()
            continue

        elif command == "create_table":
            table_name = args[1]
            columns = args[2:]
            result = create_table(metadata, table_name, columns)
            if result is not None:
                metadata = result
                save_metadata(METADATA_FILE, metadata)

        elif command == "drop_table":
            table_name = args[1]
            result = drop_table(metadata, table_name)
            if result is not None:
                metadata = result
                save_metadata(METADATA_FILE, metadata)

        elif command == "list_tables":
            list_tables(metadata)

        elif command == "insert":
            if args[1].lower() != "into" or "values" not in args:
                print("Некорректная команда insert.")
                continue
            table_name = args[2]
            values_str = user_input.split("values", 1)[1].strip()
            values_str = values_str.strip("()")
            values = [v.strip().strip('"').strip("'") for v in values_str.split(",")]

            table_data = load_table_data(table_name)
            result = insert(metadata, table_name, values, table_data)
            if result is not None:
                table_data = result
                save_table_data(table_name, table_data)

        elif command == "select":
            if args[1].lower() != "from":
                print("Некорректная команда select.")
                continue
            table_name = args[2]
            table_data = load_table_data(table_name)
            if "where" in args:
                where_index = args.index("where") + 1
                where_clause = parse_where_clause(args[where_index:])
                result = cache(f"{table_name}-{where_clause}", lambda: select(metadata, table_name, table_data, where_clause))
            else:
                result = cache(f"{table_name}-all", lambda: select(metadata, table_name, table_data))
            # Вывод select осуществляется внутри функции select

        elif command == "update":
            table_name = args[1]
            set_index = args.index("set") + 1
            where_index = args.index("where")
            set_clause = parse_set_clause(args[set_index:where_index])
            where_clause = parse_where_clause(args[where_index + 1:])
            table_data = load_table_data(table_name)
            result = update(metadata, table_name, table_data, set_clause, where_clause)
            if result is not None:
                table_data = result
                save_table_data(table_name, table_data)

        elif command == "delete":
            if args[1].lower() != "from" or "where" not in args:
                print("Некорректная команда delete.")
                continue
            table_name = args[2]
            where_index = args.index("where") + 1
            where_clause = parse_where_clause(args[where_index:])
            table_data = load_table_data(table_name)
            result = delete(metadata, table_name, table_data, where_clause)
            if result is not None:
                table_data = result
                save_table_data(table_name, table_data)

        elif command == "info":
            table_name = args[1]
            info(metadata, table_name)

        else:
            print(f"Функции {command} нет. Попробуйте снова.")
